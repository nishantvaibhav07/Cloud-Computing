const apiUrl = "https://w21f7ovjx5.execute-api.us-east-1.amazonaws.com";
let previousCount = null;
let sessionAdded = 0;
let secondsElapsed = 0;
let logEvents = [];

// Web Audio API chime generator for check-ins
function playChime() {
    try {
        const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        const osc = audioCtx.createOscillator();
        const gainNode = audioCtx.createGain();
        
        osc.type = 'sine';
        osc.frequency.setValueAtTime(587.33, audioCtx.currentTime); // D5 note
        osc.frequency.exponentialRampToValueAtTime(880, audioCtx.currentTime + 0.15); // A5 note
        
        gainNode.gain.setValueAtTime(0.15, audioCtx.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.3);
        
        osc.connect(gainNode);
        gainNode.connect(audioCtx.destination);
        
        osc.start();
        osc.stop(audioCtx.currentTime + 0.3);
    } catch (e) {
        console.log("Audio context not allowed yet");
    }
}

// Uptime counter timer
setInterval(() => {
    secondsElapsed++;
    const mins = String(Math.floor(secondsElapsed / 60)).padStart(2, '0');
    const secs = String(secondsElapsed % 60).padStart(2, '0');
    const uptimeEl = document.getElementById('uptimeTimer');
    if (uptimeEl) uptimeEl.innerText = `${mins}:${secs}`;
}, 1000);

function exportLogs() {
    if (logEvents.length === 0) {
        alert("No check-in events recorded yet in this session!");
        return;
    }
    let csvContent = "data:text/csv;charset=utf-8,Timestamp,Event\n";
    logEvents.forEach(e => {
        csvContent += `${e.time},${e.text}\n`;
    });
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "visitor_logs.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// Reset Counter Functionality
async function resetCounter() {
    if (!confirm("Are you sure you want to reset the visitor counter to 0?")) return;

    try {
        const response = await fetch(apiUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'reset' })
        });

        if (response.ok) {
            previousCount = 0;
            sessionAdded = 0;
            const sessionIncrementsEl = document.getElementById('sessionIncrements');
            if (sessionIncrementsEl) sessionIncrementsEl.innerText = "0 Visitors";
            
            const countElement = document.getElementById('visitorCount');
            if (countElement) countElement.innerText = "0";
            
            const timeString = new Date().toLocaleTimeString();
            logEvents.push({ time: timeString, text: "Counter manually reset" });

            const logContainer = document.getElementById('logContainer');
            if (logContainer) {
                const logItem = document.createElement('div');
                logItem.className = 'log-item';
                logItem.innerHTML = `Counter manually reset @ ${timeString} <span class="reset-tag">[RESET]</span>`;
                logContainer.prepend(logItem);
            }

            alert("Counter successfully reset to 0!");
        } else {
            alert("Failed to reset counter on the server.");
        }
    } catch (error) {
        console.error("Error resetting counter:", error);
        alert("Network error while trying to reset.");
    }
}

async function fetchVisitorCount() {
    const startTime = performance.now();
    try {
        const response = await fetch(apiUrl);
        const endTime = performance.now();
        const latency = Math.round(endTime - startTime);
        
        const latencyEl = document.getElementById('latencyIndicator');
        if (latencyEl) {
            latencyEl.innerHTML = `API Latency: <span style="color: #38bdf8;">${latency} ms</span>`;
        }

        const data = await response.json();
        // Fixed property name to match Lambda output ('count')
        const currentCount = data.count !== undefined ? data.count : 0;
        
        const countElement = document.getElementById('visitorCount');
        const mainCard = document.getElementById('mainCard');
        
        if (countElement) {
            if (previousCount !== null && currentCount > previousCount) {
                const diff = currentCount - previousCount;
                sessionAdded += diff;
                const sessionIncEl = document.getElementById('sessionIncrements');
                if (sessionIncEl) sessionIncEl.innerText = `${sessionAdded} Visitors`;

                playChime();

                countElement.classList.add('bump');
                if (mainCard) mainCard.classList.add('flash');
                setTimeout(() => {
                    countElement.classList.remove('bump');
                    if (mainCard) mainCard.classList.remove('flash');
                }, 400);
                
                const logContainer = document.getElementById('logContainer');
                const timeString = new Date().toLocaleTimeString();
                
                logEvents.push({ time: timeString, text: `Visitor check-in (+${diff})` });

                if (logContainer) {
                    const logItem = document.createElement('div');
                    logItem.className = 'log-item';
                    logItem.innerHTML = `Visitor check-in @ ${timeString} <span>+${diff}</span>`;
                    logContainer.prepend(logItem);
                }
            }

            countElement.innerText = currentCount;
        }
        previousCount = currentCount;
    } catch (error) {
        console.error("Error communicating with API Gateway:", error);
        const countElement = document.getElementById('visitorCount');
        if (countElement && previousCount === null) {
            countElement.innerText = 'Error';
        }
    }
}

// Initial fetch and polling loop every 3 seconds
fetchVisitorCount();
setInterval(fetchVisitorCount, 3000);